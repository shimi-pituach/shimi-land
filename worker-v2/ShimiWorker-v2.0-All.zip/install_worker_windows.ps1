# ShimiWorker v2 — התקנת Windows (PowerShell) — גרסה שלא נסגרת בשקט
# אם החלון נסגר מיד בדאבל-קליק — זו מדיניות הביטחון של וינדוז. הפתרון המדויק:
# פתח PowerShell (מקש ימני על התחל ← "Windows PowerShell" או "Terminal") והדבק:
#   powershell -ExecutionPolicy Bypass -File install_worker_windows.ps1

$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$host.UI.RawUI.WindowTitle = "ShimiWorker v2 — התקנה"
Write-Host ""
Write-Host "═══ ShimiWorker v2.0 — התקנה ל-Windows ═══" -ForegroundColor Yellow
Write-Host ""
try {
  # 1) Python
  try { $py = (python --version 2>&1) } catch { $py = $null }
  if (-not $py -or $py -match "לא נמצא|not recognized") {
    Write-Host "[1/6] Python לא נמצא — מתקין דרך winget..."
    winget install -e --id Python.Python.3.11
    if ($LASTEXITCODE -ne 0) { throw "התקנת Python נכשלה. התקן ידנית מ-python.org והרץ שוב." }
  } else { Write-Host "[1/6] Python: $py" }

  # 2) PyTorch
  Write-Host "[2/6] מתקין PyTorch..."
  $nvidia = Get-WmiObject Win32_VideoController | Where-Object { $_.Name -match "NVIDIA" }
  if ($nvidia) {
    python -m pip install --quiet torch torchvision --index-url https://download.pytorch.org/whl/cu121
    Write-Host "      כרטיס NVIDIA: $($nvidia.Name) — הותקן CUDA build"
  } else {
    python -m pip install --quiet torch torchvision
    Write-Host "      לא זוהה NVIDIA — הותקן CPU build (יעבוד, לאט יותר)" -ForegroundColor DarkYellow
  }
  python -m pip install --quiet diffusers transformers accelerate safetensors ftfy toml einops voluptuous requests

  # 3) Git + מנוע kohya
  if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "[3/6] מתקין Git..."
    winget install -e --id Git.Git
  }
  Write-Host "[3/6] מתקין מנוע kohya (sd-scripts)..."
  if (-not (Test-Path "sd-scripts")) { git clone --quiet --depth 1 https://github.com/kohya-ss/sd-scripts }

  # 4) תיקיות והגדרות
  Write-Host "[4/6] מכין תיקיות..."
  New-Item -ItemType Directory -Force -Path models, loras, jobs, renders | Out-Null
  if (-not (Test-Path "shimi_worker.py")) { throw "שים את shimi_worker.py באותה תיקייה לפני ההרצה!" }
  if (-not (Test-Path "config.json")) {
    @{ netboard_author = "sun-worker"; poll_seconds = 15; worker_id = "sun-main"; network_share = $true } | ConvertTo-Json | Out-File -Encoding utf8 config.json
  }

  # 5) נכסים
  Write-Host "[5/6] מוריד מודל בסיס (7GB, חד-פעמי) + לורות הרשת..."
  python shimi_worker.py fetch-model
  python shimi_worker.py fetch-loras

  # 6) בדיקה
  Write-Host "[6/6] מצב:"
  python shimi_worker.py status
  Write-Host ""
  Write-Host "═══ מוכן! פקודות: ═══" -ForegroundColor Green
  Write-Host "  canon lea            — רנדר קנוני של לאה (6 זרעים)"
  Write-Host "  canon shani          — רנדר קנוני של שני"
  Write-Host "  daemon               — מצב שירות (מקבל עבודות משימי פיתוח אוטומטית)"
  Write-Host "  self-test            — בדיקה עצמית מלאה"
} catch {
  Write-Host ""
  Write-Host "שגיאה: $_" -ForegroundColor Red
  Write-Host $_.InvocationInfo.PositionMessage -ForegroundColor DarkRed
  Write-Host ""
}
Write-Host ""
Write-Host "לחץ Enter לסגירה..."
Read-Host | Out-Null
