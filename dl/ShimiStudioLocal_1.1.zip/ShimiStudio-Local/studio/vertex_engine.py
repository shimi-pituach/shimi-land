# -*- coding: utf-8 -*-
"""ShimiStudio Local — מנוע Vertex AI (גוגל) — חיבור עצמאי, בלי בייס44 ובלי ספריות גוגל.
מקור המנוע: Google Vertex AI Model Garden (API ענן — לא מנוע שמורידים למחשב).
מזהים זמינים (14/10/2026): imagen-3.0-generate-002 (צילום ריאליסטי, ~$0.03-0.04 לתמונה),
gemini-2.5-flash-image (עריכה/יצירה), veo (וידאו, $0.40+/שנייה).
חשוב: המסנן של גוגל חוסם תוכן מיני מפורש — המנוע הזה לקו SFW בלבד (שיווק, באנרים, אפיון).
עירום/דמויות: ממשיכים עם RealVisXL מקומי.

דרישות: requests + cryptography (שתיהן כבר ב-requirements.txt).
הפעלה: שים את קובץ חשבון השירות (JSON) ב-studio/gcp-sa.json — או הגדר GOOGLE_APPLICATION_CREDENTIALS.
חסימת בילינג: אם מוחזר 403 BILLING_DISABLED — יש להדליק בילינג בפרויקט (קישור בשגיאה).
"""
import base64, json, os, time

import requests
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.serialization import load_pem_private_key

HERE = os.path.dirname(os.path.abspath(__file__))
SA_PATH = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS") or os.path.join(HERE, "gcp-sa.json")
REGION = "us-central1"
MODELS = {
    "imagen3": "imagen-3.0-generate-002",
    "gemini_image": "gemini-2.5-flash-image",
}
_TOKEN_CACHE = {"token": None, "exp": 0}


def _b64u(b: bytes) -> bytes:
    return base64.urlsafe_b64encode(b).rstrip(b"=")


def get_access_token(sa_path=None):
    """JWT RS256 מחשבון השירות -> access token (מטומן עד פקיעה)."""
    now = int(time.time())
    if _TOKEN_CACHE["token"] and _TOKEN_CACHE["exp"] > now + 60:
        return _TOKEN_CACHE["token"]
    path = sa_path or SA_PATH
    if not os.path.isfile(path):
        raise FileNotFoundError("חסר קובץ חשבון שירות: שים את ה-JSON ב-studio/gcp-sa.json או הגדר GOOGLE_APPLICATION_CREDENTIALS")
    sa = json.load(open(path))
    hdr = _b64u(json.dumps({"alg": "RS256", "typ": "JWT"}).encode())
    clm = _b64u(json.dumps({
        "iss": sa["client_email"],
        "scope": "https://www.googleapis.com/auth/cloud-platform",
        "aud": "https://oauth2.googleapis.com/token",
        "exp": now + 3600, "iat": now,
    }).encode())
    key = load_pem_private_key(sa["private_key"].encode(), password=None)
    sig = _b64u(key.sign(hdr + b"." + clm, padding.PKCS1v15(), hashes.SHA256()))
    jwt = (hdr + b"." + clm + b"." + sig).decode()
    r = requests.post("https://oauth2.googleapis.com/token",
                      data={"grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": jwt}, timeout=30)
    if r.status_code != 200:
        raise RuntimeError("טוקן גוגל נכשל: " + r.text[:200])
    d = r.json()
    _TOKEN_CACHE.update({"token": d["access_token"], "exp": now + d.get("expires_in", 3600)})
    return d["access_token"]


def generate(prompt, model="imagen3", sample_count=1, aspect="1:1", out_path="vertex_out.png", sa_path=None):
    """מייצר תמונה דרך Vertex predict ושומר לקובץ. מחזיר (path, meta) או זורק שגיאה מפורשת."""
    sa = json.load(open(sa_path or SA_PATH))
    project = sa["project_id"]
    model_id = MODELS.get(model, model)
    url = (f"https://{REGION}-aiplatform.googleapis.com/v1/projects/{project}"
           f"/locations/{REGION}/publishers/google/models/{model_id}:predict")
    body = {"instances": [{"prompt": prompt}],
            "parameters": {"sampleCount": sample_count, "aspectRatio": aspect}}
    r = requests.post(url, headers={"Authorization": "Bearer " + get_access_token(sa_path),
                                    "Content-Type": "application/json"}, json=body, timeout=180)
    if r.status_code != 200:
        err_full = r.text
        err = err_full[:400]
        if "BILLING_DISABLED" in err_full:
            raise RuntimeError("חסר בילינג בפרויקט " + project + " — הדלק ב: https://console.developers.google.com/billing/enable?project=" + project)
        if "SERVICE_DISABLED" in err_full or ("PERMISSION_DISABLED" in err_full):
            raise RuntimeError("Vertex AI API לא מופעל בפרויקט " + project + " — הדלק בקונסול: APIs & Services > Enable Vertex AI API")
        raise RuntimeError(f"Vertex {r.status_code}: {err}")
    preds = r.json().get("predictions", [])
    if not preds:
        raise RuntimeError("Vertex החזיר 0 תוצאות (בדרך כלל מסנן בטיחות — נסה פרומפט SFW)")
    img_b64 = preds[0].get("bytesBase64Encoded", "")
    if not img_b64:
        raise RuntimeError("Vertex לא החזי�ר bytes (ייתכן שהתוכן נחסם במסנן: " + str(preds[0])[:200] + ")")
    with open(out_path, "wb") as f:
        f.write(base64.b64decode(img_b64))
    return out_path, {"model": model_id, "project": project, "rai_reason": preds[0].get("raiFilteredReason", "")}


def status():
    return {"available": os.path.isfile(SA_PATH), "sa_path": SA_PATH,
            "models": MODELS, "region": REGION,
            "note": "Vertex = API ענן (לא מורידים למחשב). עירום = RealVisXL מקומי."}


if __name__ == "__main__":
    import sys
    p = sys.argv[1] if len(sys.argv) > 1 else "A single red apple on a white table, studio photo"
    out, meta = generate(p, out_path="vertex_out.png")
    print("נשמר:", out, meta)
