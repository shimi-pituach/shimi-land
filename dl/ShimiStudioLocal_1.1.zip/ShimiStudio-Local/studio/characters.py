# -*- coding: utf-8 -*-
"""ShimiStudio Local — דמויות קנוניות (מקור: poker-dev/canonical, אושר על ידי סאן).
כל דמות: מידות חישוביות, בלוקי גוף מינימליים, ביגוד טסט, פוזות מוכחות.
סאן הוא בעל הקנון — הקובץ הזה משקף את הגרסה המאושרת בלבד."""

# בלוק ביגוד טסט לאדם אמיתי (קנון v2.1 — חזיית תחרת פרחים לא מרופדת בלי ברזלים + חוטיני דק)
TEST_CLOTHES_REAL = (
    "wearing minimal studio test attire: a delicate sheer floral lace bralette, completely unpadded "
    "and unlined, no underwire, no support band, thin soft lace fabric with visible floral embroidery, "
    "thin spaghetti straps, natural unshaped bust silhouette; matching minimalist thin string bikini "
    "bottom, only thin string sides at the hips, high-cut, no wide waistband, no shorts, "
    "no second layer of clothing over the bottom; bare hips"
)
TEST_CLOTHES_NEG = (
    "sports bra, padded bra, underwire, push-up, thick straps, wide elastic band, shorts, jeans, "
    "boyshorts, leotard, extra layer, leggings, swimsuit bottoms with wide sides"
)
# ביגוד טסט לדמות סינתטית (קנון v2 מאושר 14/10): טופלס + חוטיני תחרת פרחים דק שקוף
TEST_APPAREL_SYNTH = (
    "topless, bare natural bust, wearing only a thin sheer floral lace thong, "
    "full body photograph, head to toe"
)
NUDE_BLOCK = "completely nude, no clothing, no underwear"  # לפי סגנון סאן: nude בתחילת הפרומפט

POSES = {
    "front": "standing, facing the camera",
    "back":  "back view, facing away, back of her head visible",
    "side":  "side profile view, face toward the camera",
    "allfours_back": "on all fours on a bed, rear view, head turned away, arched back",
    "allfours_side": "on all fours on a bed, side view, face to the camera, arched back",
    "allfours_back_hold": "on all fours, rear view, head turned away, one hand squeezing her own buttock",
    "allfours_side_hold": "on all fours, side view, face to the camera, one hand cupping her own bare breast",
}
# עוגן לכל יד (לקח 14/10: arms relaxed מקולקל, לכל יד משפט עוגן משלה)
GLUTE_BLOCK = "full round firm perky buttocks"

CHARACTERS = {
    "sigal": {
        "label": "סיגל",
        "desc": "הגותית. חזה ענק טבעי כבד, שעון חול מלא, ישבן עגול בולט. לא רזה, לא אנורקטית.",
        "measurements": {"bust": 101, "underbust": 74, "waist": 64, "hips": 104, "height": 168},
        "face": "long black hair with blunt bangs, pale skin, dark gothic makeup",
        "body": "massive natural bust, narrow waist, wide hips, huge round buttocks",
        "banned": ["anorexic", "slim figure", "thin"],
    },
    "katie": {
        "label": "קייטי",
        "desc": "מאמנת כושר. גוף מוצק וחטוב, שומן נמוך, חזה זקור, ישבן עגול מוצק. רפרנס: assets/characters/katie/katie_reference_bw_bun.jpg",
        "measurements": {"bust": 94, "underbust": 72, "waist": 60, "hips": 92, "height": 165},
        "face": "dark hair in a bun",
        "body": "firm perky breasts, fit toned body, low body fat, firm round glutes",
        "banned": ["huge natural heavy bust"],
    },
    "jean": {
        "label": "ג'ין",
        "desc": "חזה סיליקון זקור במידה גדולה, בטן עגולה, גוף לא שעון חול. רפרנס: assets/characters/jean/",
        "measurements": {"bust": 100, "underbust": 76, "waist": 66, "hips": 106, "height": 170},
        "face": "chestnut brown hair",
        "body": "large round silicone breasts, implant look, soft round belly, full buttocks",
        "banned": ["hourglass"],
    },
    "carmel": {
        "label": "קרמל",
        "desc": "מקורית (14/10). עור נחושת חם, חזה טבעי עצום וכבד, ישבן עגול רחב. קנון מלא ב-assets/characters/carmel_lookalike.md",
        "measurements": {"bust": 110, "underbust": 82, "waist": 78, "hips": 112, "height": 172},
        "face": "warm copper-brown skin, long black hair with one light streak, gold hoop earrings, warm smile",
        "body": "very large heavy natural bust, narrow waist, wide round hips",
        "banned": [],
    },
    "lola": {
        "label": "לולה (חסומה)",
        "desc": "חסומה בהוראת סאן עד קבלת מפרט מילולי מאושר (גיל, שיער, עיניים, מידות, נפח חזה). טיוטה: שיער נחושת גלי, עיניים ירוקות, שעון חול.",
        "measurements": None,  # None = חסום: המנוע מסרב לייצר עד שהמפרט יאושר בקוד
        "face": None, "body": None, "banned": ["hourglass"],
    },
}


def measure_block(m):
    """בלוק מידות חישובי — מספרים לפני תוארים (עקרון סאן 14/10)."""
    if not m:
        return ""
    return f"bust {m['bust']}cm, waist {m['waist']}cm, hips {m['hips']}cm"


# ביגוד טסט אמיתי קומפקטי (כל אילוצי הקנון v2.1 ב-25 מילים — הגרסה המלאה מילולית ב-assets/characters/test_clothes_prompt.md)
TEST_CLOTHES_REAL_COMPACT = (
    "wearing a delicate sheer floral lace bralette, unpadded, unlined, no underwire, "
    "thin spaghetti straps, matching thin string bikini bottom, thin string sides, "
    "no wide waistband, no shorts"
)


def build_character_prompt(name, pose="front", apparel="synthetic_v2", style_block="", return_info=False):
    """בונה פרומפט קנוני בתקציב 77 הטוקנים (לקח 13/10), לפי סדר עדיפויות מוכח (14/10):
    ביגוד/עירום ← פוזה ← פנים ← מידות ← גוף ← ישבן ← מסגור ← סגנון. מה שלא נכנס נחתך מהסוף, בלי הפתעות."""
    ch = CHARACTERS.get(name)
    if not ch:
        raise ValueError(f"דמות לא מוכרת: {name}")
    if ch["measurements"] is None:
        raise ValueError(
            f"דמות '{ch['label']}' חסומה עד אישור מפרט מילולי מסאן (כלל הברזל: בלי להמציא מידות)."
        )
    pose_s = POSES.get(pose, POSES["front"])
    if apparel == "nude":
        head = "completely nude"
    elif apparel == "synthetic_v2":
        head = "topless, bare natural bust, wearing only a thin sheer floral lace thong"
    elif apparel == "real_test":
        head = TEST_CLOTHES_REAL_COMPACT
    elif apparel == "none":
        head = ""
    else:
        raise ValueError(f"ביגוד לא מוכר: {apparel}")
    tail = [  # לפי סדר עדיפויות — מהסוף נחתך ראשון
        (style_block or "photorealistic studio photo"),
        "full body photograph, head to feet visible" if not pose.startswith("allfours") else "",
    ]
    if pose.startswith("allfours"):
        tail.insert(0, GLUTE_BLOCK)
    tail.insert(0, ch["body"])
    tail.insert(0, measure_block(ch["measurements"]))
    tail.insert(0, ch["face"])
    tail.insert(0, pose_s)
    parts = [head] + [t for t in tail if t]
    prompt = ""
    trimmed = False
    for p in parts:
        cand = (prompt + (", " if prompt else "") + p) if p else prompt
        if len(cand.split()) > 59:
            trimmed = True
            break
        prompt = cand
    if return_info:
        return {"prompt": prompt, "trimmed": trimmed}
    return prompt
