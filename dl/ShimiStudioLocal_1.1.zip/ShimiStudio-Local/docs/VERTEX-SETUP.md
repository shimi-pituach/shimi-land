# Vertex AI — התקנה ושימוש (ShimiStudio Local)

## מה זה
גוגל ורטקס = מנועי תמונה בענן (API). זה לא מנוע שמורידים למחשב —
המנועים רצים אצל גוגל ואנחנו קוראים להם דרך REST.

## איפה המנוע (Model Garden)
https://console.cloud.google.com/vertex-ai/model-garden
מזהים בשימוש שלנו:
1. imagen-3.0-generate-002 — צילום ריאליסטי (~$0.03-0.04 לתמונה 1024)
2. gemini-2.5-flash-image — יצירה/עריכה
3. veo — וידאו (~$0.40 לשנייה)

## התקנה (3 צעדים)
1. דרישות: pip install cryptography (כבר ב-requirements.txt)
2. שים את קובץ חשבון השירות של גוגל ב-studio/gcp-sa.json
   (הקובץ שלנו: shimiio-service-account.json, פרויקט shimiio)
3. הדלק בילינג בפרויקט — חד-פעמי, רק סאן:
   https://console.developers.google.com/billing/enable?project=shimiio
   בלי בילינג גוגל תחזיר 403 BILLING_DISABLED.

## שימוש
```python
from vertex_engine import generate
out, meta = generate("studio photo of a modern kitchen", model="imagen3", aspect="16:9", out_path="out.png")
```
או משורת הפקודה: python vertex_engine.py "תיאור התמונה"

## דרך בייס44 (בלי התקנה מקומית)
POST https://solas-6a095a77.base44.app/functions/vertexImage
עם {"prompt": "..."} — מחזיר image_base64. אותו חשבון שירות מאוחסן בכספת.

## גבול חשוב (לא המצאה שלנו — מסנן גוגל)
תוכן מיני מפורש נחסם על ידי גוגל ואי אפשר לכבות את זה.
לכן: וורטקס = קו SFW בלבד (שיווק, באנרים, אפיון, ניסויי קומפוזיציה).
עירום/דמויות למבחן האמון — RealVisXL מקומי, כמו שעובד בקגל.
