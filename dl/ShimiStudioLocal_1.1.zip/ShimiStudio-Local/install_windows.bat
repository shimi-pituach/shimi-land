@echo off
chcp 65001 >nul
title ShimiStudio Local - Installer
echo ============================================
echo   ShimiStudio Local - Windows Installer
echo ============================================
where py >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python לא מותקן. הורד Python 3.11 מ- python.org והפעל שוב.
  pause & exit /b 1
)
py -3.11 -m venv venv 2>nul || py -3 -m venv venv
call venv\Scripts\activate.bat
python -m pip install --upgrade pip -q
echo [1/3] מתקין PyTorch (גרסת CUDA — עשוי לקחת דקות)...
pip install torch --index-url https://download.pytorch.org/whl/cu121 -q
echo [2/3] מתקין ספריות...
pip install -r requirements.txt -q
echo [VERTEX] מנוע גוגל וורטקס (אופציונלי)...
pip install cryptography -q
if not exist "studio\gcp-sa.json" (
  echo [VERTEX] אין studio\gcp-sa.json — וורטקס לא יהיה זמין עד שתשים את קובץ חשבון השירות. פירוט: docs\VERTEX-SETUP.md
) else (
  echo [VERTEX] חשבון שירות נמצא — וורטקס יהיה זמין אחרי הפעלת בילינג בפרויקט.
)
echo [3/3] מוריד מודלים ולורות (RealVisXL ~7GB. אפשר לדלג ולהריץ מאוחר יותר)...
python download_models.py
echo נוצר קובץ הפעלה בשולחן העבודה...
powershell -NoProfile -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\ShimiStudio Local.lnk'); $s.TargetPath='%~dp0START-WINDOWS.bat'; $s.WorkingDirectory='%~dp0'; $s.Save()"
echo הושלם! לחץ פעמיים על "ShimiStudio Local" בשולחן העבודה.
pause
