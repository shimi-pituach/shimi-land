# -*- coding: utf-8 -*-
"""ShimiStudio Local — השרת המקומי. פייתון סטנדרטי בלבד (בלי Flask/FastAPI), אפס תלות חוץ מ-torch/diffusers.
רץ על המחשב שלך, מגיש את ה-UI בדפדפן (גם מהאייפד באותו רשת). בלי ענן, בלי וורקרים, בלי Base44.
מצב בדיקה: SHIMI_MOCK=1 python app.py  → מנועים מדומים (לבדיקת ה-UI בלי GPU)."""

import json
import os
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
ROOT = os.path.dirname(_HERE)
OUTPUT = os.path.join(_HERE, "output")
HISTORY = os.path.join(_HERE, "history")
UI_DIR = os.path.join(_HERE, "ui")
MOCK = os.environ.get("SHIMI_MOCK") == "1"
PORT = int(os.environ.get("SHIMI_PORT", "7861"))
HOST = os.environ.get("SHIMI_HOST", "0.0.0.0")  # 0.0.0.0 → נגיש לאייפד ברשת הבית

os.makedirs(OUTPUT, exist_ok=True)
os.makedirs(HISTORY, exist_ok=True)

import characters
import prompts as promptlib

_GEN_LOCK = threading.Lock()


def _safe_name(s):
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in s)[:80]


def do_generate(params):
    """רינדור תמונה: דמות+פוזה+ביגוד או טקסט חופשי. מחזיר נתיב קובץ + שער איכות."""
    t0 = time.time()
    char = params.get("character") or ""
    pose = params.get("pose") or "front"
    apparel = params.get("apparel") or ("synthetic_v2" if char else "none")
    engine = params.get("engine") or "realvisxl_v5"
    style = params.get("style") or "photorealistic"
    mood = params.get("mood")
    free_text = params.get("prompt", "")
    negative = params.get("negative", "")
    seed = int(params.get("seed") or 0)
    steps = int(params.get("steps") or 32)
    cfg = float(params.get("cfg") or 6.0)
    landscape = params.get("orientation") == "wide"
    lora_dir = params.get("lora_dir") or ""
    lora_scale = float(params.get("lora_scale") or 0.8)
    keep_in_history = params.get("history", True)

    w, h = (1536, 1024) if landscape else (1024, 1536)

    # בניית פרומפט: דמות קנונית או טקסט חופשי
    if char:
        # הדמות + הפוזה שלה = בסיס קנוני; הפרומפט של המשתמש מתווסף אליו (לא מבטל) — סאן 16/10
        built = characters.build_character_prompt(
            char, pose=pose, apparel=apparel,
            style_block=promptlib.STYLES.get(style, ""),
            extra=free_text, return_info=True)
        if not negative:
            negative = promptlib.NEGATIVE_TEST_CLOTHES if apparel == "real_test" else promptlib.NEGATIVE_DEFAULT
    else:
        built = promptlib.build(free_text=free_text, style=style, mood=mood,
                                nude=params.get("nude", False))
        if not negative:
            negative = promptlib.NEGATIVE_DEFAULT

    tag = _safe_name(f"{char or 'free'}_{pose}_{int(time.time())}")
    out_path = os.path.join(OUTPUT, f"{tag}.png")

    if MOCK:
        from PIL import Image, ImageDraw
        import random
        img = Image.new("RGB", (w, h), (60 + random.randint(0, 40), 30, 40))
        d = ImageDraw.Draw(img)
        d.text((20, 20), f"MOCK {engine} seed={seed}", fill=(240, 240, 240))
        d.rectangle((w // 4, h // 4, 3 * w // 4, 3 * h // 4), fill=(180, 140, 120))
        img.save(out_path)
        ok, info = True, {"faces": 1, "skin": 0.6, "bytes": os.path.getsize(out_path),
                          "w": w, "h": h, "mock": True}
    else:
        import engines
        with _GEN_LOCK:
            img = engines.generate_image(
                engine, built["prompt"], negative=negative, seed=seed, width=w, height=h,
                steps=steps, cfg=cfg,
                lora_dir=(lora_dir if lora_dir and os.path.isdir(lora_dir) else None),
                lora_scale=lora_scale)
            img.save(out_path)
        import gates
        expect = "back" if "back" in pose else ("front" if ("front" in pose or "side" in pose) else "any")
        g = gates.analyze(out_path, expect=expect)
        ok = g["ok"]
        info = {k: g[k] for k in ("faces", "skin", "bytes", "w", "h")}
        info["gate_detail"] = {k: g[k] for k in ("face_ok", "skin_ok", "size_ok")}

    if keep_in_history:
        import shutil
        shutil.copy(out_path, os.path.join(HISTORY, os.path.basename(out_path)))

    return {"ok": True, "file": os.path.basename(out_path), "gate_pass": ok,
            "gate": info, "prompt": built["prompt"], "trimmed": built["trimmed"],
            "seconds": round(time.time() - t0, 1),
            "url": f"/output/{os.path.basename(out_path)}"}


def do_img2img(params):
    """img2img — הדרך המוכחת לפוזות גב. params: init=path|base64, strength."""
    import base64
    import gates
    init = params.get("init") or ""
    strength = float(params.get("strength") or 0.75)
    engine = params.get("engine") or "realvisxl_v5"
    prompt = params.get("prompt", "")
    negative = params.get("negative") or promptlib.NEGATIVE_DEFAULT
    seed = int(params.get("seed") or 0)
    if not prompt:
        return {"ok": False, "error": "חסר פרומפט"}
    t0 = time.time()
    tag = _safe_name(f"i2i_{int(time.time())}")
    out_path = os.path.join(OUTPUT, f"{tag}.png")
    if MOCK:
        from PIL import Image, ImageDraw
        img = Image.new("RGB", (1024, 1024), (40, 40, 60))
        ImageDraw.Draw(img).text((20, 20), f"MOCK i2i {strength}", fill=(240, 240, 240))
        img.save(out_path)
    else:
        import engines
        src = init
        if init.startswith("data:image"):
            raw = base64.b64decode(init.split(",", 1)[1])
            src = os.path.join(OUTPUT, f"_{tag}_init.png")
            open(src, "wb").write(raw)
        with _GEN_LOCK:
            img = engines.img2img(engine, src, prompt, negative=negative,
                                  strength=strength, seed=seed)
            img.save(out_path)
    g = gates.analyze(out_path, expect="any")
    return {"ok": True, "file": os.path.basename(out_path), "gate_pass": g["ok"],
            "gate": {k: g[k] for k in ("faces", "skin", "bytes", "w", "h")},
            "seconds": round(time.time() - t0, 1), "url": f"/output/{os.path.basename(out_path)}"}


def do_video(params):
    """וידאו: LTX (מתמונה) או Wan 2.1 (מטקסט)."""
    engine = params.get("engine") or "ltx_video"
    image_path = params.get("image") or ""
    prompt = params.get("prompt") or ""
    seed = int(params.get("seed") or 0)
    tag = _safe_name(f"vid_{int(time.time())}")
    out_path = os.path.join(OUTPUT, f"{tag}.mp4")
    t0 = time.time()
    if MOCK:
        import struct
        with open(out_path, "wb") as f:
            f.write(b"MOCKVIDEO" + struct.pack("i", seed))
    else:
        import video as videolib
        if engine == "ltx_video":
            if not image_path or not os.path.isfile(image_path):
                return {"ok": False, "error": "LTX דורש תמונת מקור (נתיב קובץ מקומי)"}
            videolib.generate_video_ltx_i2v(image_path, prompt or "subtle natural motion",
                                            out_path, seed=seed)
        elif engine == "wan21_t2v13b":
            videolib.generate_video_wan_t2v(prompt, out_path, seed=seed)
        else:
            return {"ok": False, "error": f"מנוע וידאו לא מוכר: {engine}"}
    return {"ok": True, "file": os.path.basename(out_path),
            "seconds": round(time.time() - t0, 1), "url": f"/output/{os.path.basename(out_path)}"}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith("text/") or ctype == "application/json" else ""))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _static(self, rel, ctype):
        fp = os.path.join(_HERE, rel)
        if not os.path.isfile(fp):
            self._send(404, {"error": "not found"})
            return
        with open(fp, "rb") as f:
            self._send(200, f.read(), ctype)

    def do_GET(self):
        u = urlparse(self.path)
        p = u.path
        if p in ("/", "/index.html"):
            self._static(os.path.join("ui", "index.html"), "text/html")
        elif p == "/api/state":
            state = {"mock": MOCK}
            try:
                if MOCK:
                    state["device"] = "cpu (mock)"
                    state["engines"] = {"realvisxl_v5": {"desc": "מדומה", "downloaded": True}}
                    state["video"] = {"ltx_video": {"desc": "מדומה", "kind": "i2v"}}
                else:
                    import engines, video as videolib
                    try:
                        state.update(engines.status())
                    except Exception as e:
                        state["device"] = "חסר PyTorch"
                        state["setup_error"] = str(e)[:200]
                    state.setdefault("engines", {k: {"desc": v["desc"], "downloaded": False}
                                                for k, v in engines.IMAGE_ENGINES.items()})
                    try:
                        state["video"] = videolib.status()
                    except Exception as e:
                        state["video"] = {}
                        state["setup_error"] = (state.get("setup_error") or "") + " | " + str(e)[:150]
            except Exception as e:
                state["error"] = str(e)[:200]
            state["characters"] = {k: {"label": v["label"], "desc": v["desc"],
                                       "locked": bool(v.get("blocked"))}
                                   for k, v in characters.CHARACTERS.items()}
            state["poses"] = list(characters.POSES.keys())
            state["styles"] = list(promptlib.STYLES.keys())
            state["moods"] = list(promptlib.MOODS.keys())
            self._send(200, state)
        elif p.startswith("/output/"):
            self._static(os.path.join("output", os.path.basename(p)), "image/png" if p.endswith(".png") else "video/mp4")
        elif p.startswith("/history/"):
            self._static(os.path.join("history", os.path.basename(p)), "image/png")
        elif p == "/api/history":
            files = sorted(os.listdir(HISTORY), reverse=True)[:100]
            self._send(200, {"files": [f for f in files if f.endswith(".png")]})
        else:
            self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self._send(400, {"error": "בקשה לא תקינה"})
        try:
            if u.path == "/api/generate":
                return self._send(200, do_generate(body))
            if u.path == "/api/img2img":
                return self._send(200, do_img2img(body))
            if u.path == "/api/video":
                return self._send(200, do_video(body))
        except ValueError as e:
            return self._send(400, {"error": str(e)})
        except Exception as e:
            import traceback
            traceback.print_exc()
            return self._send(500, {"error": str(e)[:300]})
        self._send(404, {"error": "not found"})


def main():
    url = f"http://localhost:{PORT}"
    print(f"ShimiStudio Local {'[MOCK] ' if MOCK else ''}↑ {url}  (אייפד: אותה כתובת עם ה-IP של המחשב)")
    if os.environ.get("SHIMI_NO_BROWSER") != "1":
        try:
            webbrowser.open(url)
        except Exception:
            pass
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    server.serve_forever()


if __name__ == "__main__":
    main()
