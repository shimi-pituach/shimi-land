@echo off
chcp 65001 >nul
title ShimiStudio - התקנה לווינדוז (קובץ אחד)
echo =====================================================
echo   ShimiStudio Local v1.3 - התקנה לווינדוז
echo   קובץ אחד. רץ עד הסוף. בסיום הדפדפן נפתח לבד.
echo =====================================================
cd /d "%~dp0ShimiStudio-Local"
where py >nul 2>&1
if errorlevel 1 (
  where python >nul 2>&1
  if errorlevel 1 (
    echo [שגיאה] Python לא מותקן. מתקין עכשיו (ווינגט)...
    winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    echo Python הותקן. סוגרים חלון זה ומריצים את הקובץ פעם נוספת - זה החלק היחיד שדורש פעמיים.
    pause & exit /b 0
  )
)
py -3 -m venv venv 2>nul || python -m venv venv
call venv\Scripts\activate.bat
python -m pip install --upgrade pip -q
echo [1/4] מתקין PyTorch. אם יש כרטיס NVIDIA - גרסת CUDA (גדול, כמה דקות). אחרת CPU.
nvidia-smi >nul 2>&1
if not errorlevel 1 (
  pip install torch --index-url https://download.pytorch.org/whl/cu121 -q
) else (
  echo        לא זוהה NVIDIA - מתקין גרסת CPU.
  pip install torch -q
)
pip install accelerate -q
echo [2/4] מתקין ספריות (diffusers, transformers, opencv ועוד)...
pip install -r requirements.txt -q
echo [3/4] מוריד מודלים. RealVisXL ~7GB + לורות ~1GB.
echo        אפשר לסגור את החלון - בפעם הבאה ההורדה ממשיכה מאיפה שנעצרה.
python download_models.py
echo [4/4] מפעיל את הסטודיו...
start "" http://localhost:7861
venv\Scripts\python.exe studio\app.py
pause
