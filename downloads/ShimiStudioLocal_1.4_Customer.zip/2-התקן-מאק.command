#!/bin/zsh
# ShimiStudio Local v1.3 — התקנה למאק. קובץ אחד.
# אם הדפדפן מוריד את הקובץ במקום להריץ: קליק ימני על הקובץ → "פתח" (פעם אחת).
cd "$(dirname "$0")/ShimiStudio-Local" || exit 1
echo "════════════════════════════════════════"
echo "  ShimiStudio Local v1.3 — התקנה למאק"
echo "════════════════════════════════════════"
if ! command -v python3 >/dev/null; then
  echo "Python לא מותקן — נפתחת התקנת כלי הפיתוח של אפל (אישור אחד)."
  xcode-select --install
  echo "אחרי שההתקנה של אפל מסתיימת — להריץ את הקובץ הזה שוב."
  exit 0
fi
python3 -m venv venv
source venv/bin/activate
python3 -m pip install --upgrade pip -q --break-system-packages 2>/dev/null || python3 -m pip install --upgrade pip -q
echo "[1/4] מתקין PyTorch (גרסת Apple Silicon / MPS)..."
pip install torch -q --break-system-packages 2>/dev/null || pip install torch -q
pip install accelerate -q --break-system-packages 2>/dev/null || pip install accelerate -q
echo "[2/4] מתקין ספריות..."
pip install -r requirements.txt -q --break-system-packages 2>/dev/null || pip install -r requirements.txt -q
echo "[3/4] מוריד מודלים (RealVisXL ~7GB). אפשר לסגור — ההורדה ממשיכה בהרצה הבאה."
python3 download_models.py
echo "[4/4] מפעיל את הסטודיו..."
open "http://localhost:7861"
python3 studio/app.py
