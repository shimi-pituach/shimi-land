# -*- coding: utf-8 -*-
"""ShimiStudio Local — דמויות (גרסת לקוח).
הדמויות מוגדרות כאן בפורמט פשוט — הוסיפו דמויות משלכם בעצמכם לפי התבנית.
לכל דמות: מידות (אופציונלי), בלוק פנים, בלוק גוף, מילים אסורות."""

TEST_CLOTHES_REAL = (
    "wearing casual outfit: a simple top and comfortable pants, natural relaxed look"
)
TEST_CLOTHES_NEG = (
    "overly complicated outfit, costume, uniform, heavy accessories"
)
NUDE_BLOCK = "completely nude, no clothing, no underwear"

POSES = {
    "front": "standing, facing the camera",
    "back":  "back view, facing away, back of her head visible",
    "side":  "side profile view, face toward the camera",
    "sitting": "sitting on a chair, facing the camera",
    "walking": "walking toward the camera, mid-stride",
}

CHARACTERS = {
    "alex": {
        "label": "אלכס (דוגמה)",
        "desc": "דמות לדוגמה — החליפו בדמויות שלכם.",
        "measurements": {"bust": 94, "underbust": 82, "waist": 74, "hips": 96, "height": 176},
        "face": "short brown hair, light stubble, friendly confident expression",
        "body": "athletic fit body, broad shoulders",
        "banned": ["obese", "skeletal"],
    },
    "maya": {
        "label": "מאיה (דוגמה)",
        "desc": "דמות לדוגמה — החליפו בדמויות שלכם.",
        "measurements": {"bust": 88, "underbust": 74, "waist": 66, "hips": 94, "height": 168},
        "face": "long dark hair, warm smile, natural makeup",
        "body": "slim healthy body, natural proportions",
        "banned": ["anorexic", "exaggerated proportions"],
    },
}

def build_character_prompt(name, pose="front", apparel="none", style_block="", extra="", return_info=False):
    """בונה פרומפט דמות בתקציב 77 הטוקנים של CLIP (~59 מילים).
    סדר: ביגוד ← פוזה ← פנים ← מידות ← גוף ← מסגור ← סגנון. מה שלא נכנס נחתך מהסוף."""
    ch = CHARACTERS.get(name)
    if not ch:
        raise ValueError(f"דמות לא מוכרת: {name}")
    pose_s = POSES.get(pose, POSES["front"])
    if apparel == "nude":
        head = NUDE_BLOCK
    elif apparel == "casual":
        head = TEST_CLOTHES_REAL
    elif apparel == "none":
        head = ""
    else:
        raise ValueError(f"ביגוד לא מוכר: {apparel}")
    tail = [
        (style_block or "photorealistic studio photo"),
        "full body photograph, head to feet visible",
    ]
    parts = [p for p in [head, pose_s, ch.get("face", ""), _measurements_text(ch), ch.get("body", "")] if p]
    if extra:
        parts.append(extra)
    parts += [t for t in tail if t]
    text = ", ".join(parts)
    words = text.split()
    cut = False
    if len(words) > 59:
        words = words[:59]
        cut = True
    result = " ".join(words)
    if return_info:
        return result, {"cut": cut, "words": len(words)}
    return result

def _measurements_text(ch):
    m = ch.get("measurements")
    if not m:
        return ""
    return (f"{m.get('height', 170)}cm tall, bust {m.get('bust', 90)}cm, "
            f"waist {m.get('waist', 70)}cm, hips {m.get('hips', 92)}cm")
