#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ShimiStudio Local — הורדת מנועים, מודלים ולורות. מוריד הכל לפני ההפעלה הראשונה.
--dry-run מציג בלי להוריד. הלורות: 10 הלורות שאספנו מ-CivitAI (מפתח שלנו) + אפשרות אימון משלך."""

import os, sys, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
CIVITAI_API_KEY = "e2326baba3956889150ad5df910ac536"

HF_ENGINES = [
    ("realvisxl_v5", "SG161222/RealVisXL_V5.0", "7GB", "המנוע הפוטוריאליסטי המוכח שלנו — ברירת מחדל"),
    ("sdxl_base", "stabilityai/stable-diffusion-xl-base-1.0", "7GB", "SDXL בסיס — גיבוי"),
]
HF_VIDEO = [
    ("ltx_video", "Lightricks/LTX-Video", "9GB", "וידאו מתמונה 5 שנ׳ (8GB VRAM)"),
    ("wan21_t2v13b", "Wan-AI/Wan2.1-T2V-1.3B-Diffusers", "6GB", "וידאו מטקסט (12GB VRAM)"),
]
LORAS_HF = [
]
LORAS = [
    ("add_detail.safetensors", "https://civitai.com/api/download/models/62833", "Detail Tweaker"),
    ("more_details.safetensors", "https://civitai.com/api/download/models/87153", "Add More Details"),
    ("epi_noiseoffset2.safetensors", "https://civitai.com/api/download/models/16576", "epi_noiseoffset"),
    ("PSCowgirl.safetensors", "https://civitai.com/api/download/models/10490", "POV Squatting Cowgirl"),
    ("nudify_xl_lite.safetensors", "https://civitai.com/api/download/models/177674", "Nudify XL Better Bodies"),
    ("innievag.safetensors", "https://civitai.com/api/download/models/12873", "Innies Better vulva"),
    ("ClothingAdjuster3.safetensors", "https://civitai.com/api/download/models/117151", "LEOSAM Clothing Adjuster"),
    ("AfterSexMS.safetensors", "https://civitai.com/api/download/models/21538", "After Sex Lying"),
    ("mix4.safetensors", "https://civitai.com/api/download/models/16677", "Cute girl mix4"),
    ("edgBondDollLikenessv1.safetensors", "https://civitai.com/api/download/models/530857", "Doll Likeness"),
]

DRY = "--dry-run" in sys.argv


def dl_hf(repo, desc):
    print(f"[HF] {repo} — {desc}")
    if DRY:
        return
    from huggingface_hub import snapshot_download
    snapshot_download(repo, allow_patterns=["*.json", "*.txt", "*.safetensors", "*.bin", "*.py"],
                      ignore_patterns=["*.pth", "*.ckpt", "*nonema*", "*fp16*"] if "RealVis" in repo else None)


def dl_lora_hf(name, repo, desc):
    dest = os.path.join(HERE, "studio", "models", "loras")
    os.makedirs(dest, exist_ok=True)
    fp = os.path.join(dest, name)
    print(f"[HF-LoRA] {name} <- {repo} — {desc}")
    if DRY or (os.path.exists(fp) and os.path.getsize(fp) > 10000):
        return
    from huggingface_hub import hf_hub_download
    hf_hub_download(repo_id=repo, filename=name, local_dir=dest)


def dl_lora(name, url, desc):
    dest = os.path.join(HERE, "studio", "models", "loras")
    os.makedirs(dest, exist_ok=True)
    fp = os.path.join(dest, name)
    print(f"[LoRA] {name} — {desc}")
    if DRY or (os.path.exists(fp) and os.path.getsize(fp) > 10000):
        return
    import requests
    r = requests.get(url, headers={"Authorization": f"Bearer {CIVITAI_API_KEY}"},
                     stream=True, allow_redirects=True, timeout=600)
    if r.status_code != 200:
        print(f"  [FAIL] HTTP {r.status_code}")
        return
    with open(fp, "wb") as f:
        for chunk in r.iter_content(1 << 20):
            f.write(chunk)
    print(f"  [OK] {os.path.getsize(fp)//1024//1024}MB")


def main():
    print("=== ShimiStudio Local — הורדת מודלים ===")
    if DRY:
        print("(מצב תצוגה בלבד, לא מוריד כלום)\n")
    for _, repo, size, desc in HF_ENGINES:
        print(f"  ~{size}")
        dl_hf(repo, desc)
    for _, repo, size, desc in HF_VIDEO:
        ans = "n" if DRY else input(f"להוריד וידאו {desc} (~{size})? y/n: ").strip().lower()
        if ans == "y":
            dl_hf(repo, desc)
    for name, url, desc in LORAS:
        dl_lora(name, url, desc)
    print("\nהורדה הושלמה. מפעילים עם: python studio/app.py (או קובץ ההפעלה)")


if __name__ == "__main__":
    main()


for n, r, d in LORAS_HF:
    dl_lora_hf(n, r, d)