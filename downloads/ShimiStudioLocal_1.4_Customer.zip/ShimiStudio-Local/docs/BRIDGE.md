# Shimi Bridge — הגשר המקומי לסוכני AI

מסמך זה מיועד לסוכן ה-AI שלכם. המטרה: הסוכן מפסיק לצרוך קרדיטים/ענן ליצירת תמונות, וידאו ועריכות — ועובר לעבוד מול הסטודיו המקומי הזה.

## כיצד הסוכן עובד עם הסטודיו
הסטודיו מריץ שרת HTTP מקומי בכתובת `http://localhost:7861`. כל הפעולות — בקשות POST רגילות:

### יצירת תמונה (בלי קרדיטים)
```
POST /api/generate
{"prompt": "...", "negative": "...", "width": 1024, "height": 1536, "steps": 30, "seed": 1234, "character": "maya", "pose": "front"}
```
התשובה מחזירה שם קובץ תמונה ב-output.

### תמונה מתמונה (img2img)
```
POST /api/img2img
{"prompt": "...", "image": "input.png", "strength": 0.65}
```

### וידאו
```
POST /api/video
{"prompt": "...", "frames": 24, "engine": "ltx"}
```

### עריכת וידאו (ffmpeg)
```
POST /api/edit
{"op": "trim", "src": "video.mp4", "start": 2, "end": 8}
```
פעולות: `info, trim, speed, concat, reels, text, watermark, audio, fade, mute, reverse, rotate, eq, gif`

### רשימת קבצים זמינים
```
GET /api/files
```

### העלאת קובץ מהלקוח
```
POST /api/upload
{"name": "clip.mp4", "data_b64": "<base64 של הקובץ>"}
```

## פרומפט מוכן להדביק לסוכן שלכם
התקין את ShimiStudio Local על המחשב שלי לפי README.md, הרם את השרת המקומי, ומעכשיו בכל בקשה שלי לתמונה, וידאו או עריכת וידאו — אל תשתמש בכלים שצורכים קרדיטים או שירותי ענן. במקום זה קרא ל-API המקומי של הסטודיו ב-http://localhost:7861 לפי docs/BRIDGE.md: /api/generate לתמונות, /api/video לוידאו, /api/edit לעריכות, /api/upload להעלאות. אם השרת לא עולה — תקן קודם את ההרצה ורק אז תמשיך. ענה לי תמיד עם שם הקובץ שיצא והיסטוריית הפעולות.
