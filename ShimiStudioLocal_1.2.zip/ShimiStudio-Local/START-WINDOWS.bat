@echo off
chcp 65001 >nul
cd /d "%~dp0"
title ShimiStudio Local

if not exist venv\Scripts\python.exe (
  echo [מזהה] ההתקנה לא הושלמה — מריץ את המתקין אוטומטית...
  call install_windows.bat
  goto :start
)

venv\Scripts\python.exe -c "import torch" >nul 2>&1
if errorlevel 1 (
  echo [מזהה] PyTorch חסר — מתקין אוטומטית. זה לוקח כמה דקות, אל תסגור את החלון...
  call venv\Scripts\activate.bat
  pip install torch --index-url https://download.pytorch.org/whl/cu121 -q
  if errorlevel 1 (
    echo [נפילה ל-CPU] מנסה גרסת PyTorch רגילה...
    pip install torch -q
  )
  pip install -r requirements.txt -q
)

:start
call venv\Scripts\activate.bat
echo מריץ את הסטודיו... הדפדפן ייפתח לבד בכתובת http://localhost:7861
python studio\app.py
pause
