@echo off
chcp 65001 >nul
title ShimiStudio Local - Installer
echo ============================================
echo   ShimiStudio Local - Windows Installer
echo ============================================
where py >nul 2>&1
if errorlevel 1 (
  where python >nul 2>&1
  if errorlevel 1 (
    echo [שגיאה] Python לא מותקן. מתקין דרך winget...
    winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    echo Python הותקן. סגור את החלון הזה, פתח חלון חדש והרץ את הקובץ שוב.
    pause
    exit /b 0
  )
)
py -3 -m venv venv 2>nul || python -m venv venv
call venv\Scripts\activate.bat
python -m pip install --upgrade pip -q
echo [1/3] מתקין PyTorch גרסת CUDA (עשוי לקחת דקות, הקובץ גדול)...
pip install torch --index-url https://download.pytorch.org/whl/cu121 -q
venv\Scripts\python.exe -c "import torch" >nul 2>&1
if errorlevel 1 (
  echo [מזהה] התקנת CUDA נכשלה — מתקין PyTorch רגיל CPU כדי שהסטודיו יעבוד בכל מקרה...
  pip install torch -q
)
echo [2/3] מתקין ספריות...
pip install -r requirements.txt -q
echo [3/3] מוריד מודלים ולורות. RealVisXL בערך 7GB — אפשר לסגור ולהריץ אחר כך דרך START.
python download_models.py
echo ─── אימות סופי ───
venv\Scripts\python.exe -c "import torch; print('PyTorch OK:', torch.__version__, '| CUDA:', torch.cuda.is_available())"
if errorlevel 1 (
  echo [שגיאה] PyTorch עדיין לא מותקן. הרץ את הקובץ הזה שוב או פנה לשימי פיתוח.
) else (
  echo הכל תקין! נוצר קיצור דרך בשולחן העבודה.
)
powershell -NoProfile -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\ShimiStudio Local.lnk'); $s.TargetPath='%~dp0START-WINDOWS.bat'; $s.WorkingDirectory='%~dp0'; $s.Save()"
pause
