# -*- coding: utf-8 -*-
"""ShimiStudio Local — בונה פרומפטים + ספריית סגנונות + ניהול תקציב 77 טוקנים (לקח 13/10)."""

import re

# תקציב ה-CLIP: 77 טוקנים לכל מקודד. כלל האצבע: מילה≈1.3 טוקנים → עד ~59 מילים.
MAX_WORDS = 59

NEGATIVE_DEFAULT = (
    "lowres, bad anatomy, bad hands, extra fingers, missing fingers, extra limbs, deformed, "
    "blurry, watermark, text, logo, cartoon, anime, illustration, painting, plastic skin, "
    "waxy skin, oversaturated, jpeg artifacts, multiple people, cropped body"
)
# שלילת ביגוד טסט לאדם אמיתי (קנון v2.1). לפוזות עירום: אפס מילות לבוש גם בשלילה (לקח 14/10).
NEGATIVE_TEST_CLOTHES = (
    "sports bra, padded bra, underwire, push-up, thick straps, wide elastic band, shorts, jeans, "
    "boyshorts, leotard, extra layer, leggings, swimsuit bottoms with wide sides"
)

STYLES = {
    "photorealistic": "photorealistic, realistic photography, natural lighting, ultra realistic skin texture, sharp focus",
    "cinematic":      "cinematic photography, dramatic lighting, shallow depth of field, film grain",
    "studio":         "professional studio photo, plain light gray seamless studio background, soft even studio lighting",
    "amateur_phone":  "amateur phone photo, natural lighting, slightly imperfect framing, no editing, authentic candid feel",
    "mirror_selfie":  "mirror selfie at home, natural window light, casual relaxed pose, realistic phone photo",
    "gym_mirror":     "gym mirror selfie, natural gym lighting, realistic phone photo",
    "oil_painting":   "classical oil painting, visible brush strokes, canvas texture",
    "anime":          "anime style, cel shading, vibrant colors",
}

MOODS = {
    "sensual": "sensual mood, warm soft lighting",
    "romantic": "romantic mood, golden hour light",
    "bold": "bold composition, strong contrast",
    "dark": "dark moody low-key lighting",
    "playful": "playful energy, bright colors",
    "intimate": "intimate setting, dim warm lighting",
}


def trim_to_budget(prompt, max_words=MAX_WORDS):
    """חיתוך חכם: שומר על התחלה (nude/ביגוד לפי לקח סאן) וגוזר מהסוף. מדווח אם נחתך."""
    words = prompt.split()
    if len(words) <= max_words:
        return prompt, False
    return " ".join(words[:max_words]), True


def build(free_text="", character_block="", style="photorealistic", mood=None,
          nude=False, test_clothes=False):
    """הרכבה סופית לפי הסגנון המוכח של סאן: עירום/ביגוד קודם, משפטי פוזה קצרים, סגנון בסוף."""
    parts = []
    if nude:
        parts.append("completely nude")
    if test_clothes:
        parts.append(character_block)
    elif free_text and character_block:
        parts.append(f"{character_block}, {free_text}")
    elif character_block:
        parts.append(character_block)
    else:
        parts.append(free_text)
    if style in STYLES:
        parts.append(STYLES[style])
    if mood and mood in MOODS:
        parts.append(MOODS[mood])
    full = ", ".join(p for p in parts if p)
    full, trimmed = trim_to_budget(full)
    full = re.sub(r"\s+", " ", full).strip()
    return {"prompt": full, "trimmed": trimmed}
