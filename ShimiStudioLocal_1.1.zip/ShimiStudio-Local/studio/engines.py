# -*- coding: utf-8 -*-
"""ShimiStudio Local — מנועי תמונה מקומיים (diffusers), ללא ענן וללא וורקרים.
מנועי אמת מוכחים מהעבודה שלנו: RealVisXL V5.0 (קגל, 14/10, 8/8 תמונות) + SDXL בסיס כגיבוי.
לקחי dtype מ-11/10 (NaN ב-UMT5 בפלוקס): הפרדת דיוק בין רכיבים, תועדה ב-KNOWLEDGE.md."""

import os, threading

DEVICE = None
_PIPE = {}
_LOCK = threading.Lock()
MODELS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")

IMAGE_ENGINES = {
    # המנוע המוכח שלנו — פוטוריאליסטי, איכות הסטודיו, זה שהוציא את סט 8/8 ב-14/10
    "realvisxl_v5": {
        "repo": "SG161222/RealVisXL_V5.0", "type": "sdxl", "min_vram_gb": 6,
        "desc": "RealVisXL V5.0 — פוטוריאליזם, ברירת המחדל של הסטודיו",
    },
    "sdxl_base": {
        "repo": "stabilityai/stable-diffusion-xl-base-1.0", "type": "sdxl", "min_vram_gb": 6,
        "desc": "SDXL בסיס — גיבוי ניטרלי",
    },
}


def detect_device():
    """cuda (NVIDIA) → mps (Apple Silicon) → cpu. מופעל פעם אחת בלבד."""
    global DEVICE
    if DEVICE:
        return DEVICE
    try:
        import torch
        if torch.cuda.is_available():
            DEVICE = ("cuda", torch.float16)
        elif getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            DEVICE = ("mps", torch.float16)
        else:
            DEVICE = ("cpu", torch.float32)
    except ImportError:
        DEVICE = ("cpu", torch.float32)
    return DEVICE


def get_pipe(engine_id):
    """טוען צינור מנוע פעם אחת ושומר בזיכרון. גם מצמיד לורות שהופעלו."""
    from diffusers import StableDiffusionXLPipeline, EulerAncestralDiscreteScheduler
    with _LOCK:
        if engine_id in _PIPE:
            return _PIPE[engine_id]
        spec = IMAGE_ENGINES[engine_id]
        dev, dtype = detect_device()
        import torch
        pipe = StableDiffusionXLPipeline.from_pretrained(spec["repo"], torch_dtype=dtype, variant="fp16")
        pipe.scheduler = EulerAncestralDiscreteScheduler.from_config(pipe.scheduler.config)
        if dev == "cuda":
            pipe = pipe.to("cuda")
        elif dev == "mps":
            pipe = pipe.to("mps")
        else:
            pipe.enable_model_cpu_offload()
        _PIPE[engine_id] = pipe
        return pipe


def apply_loras(pipe, lora_dir, scale=0.8):
    """מצמיד את כל קבצי הלורה בתיקייה. סדר קבוע = תוצאה יציבה."""
    import glob
    for fp in sorted(glob.glob(os.path.join(lora_dir, "*.safetensors"))):
        try:
            pipe.load_lora_weights(os.path.dirname(fp), weight_name=os.path.basename(fp))
            pipe.fuse_lora(lora_scale=scale)
        except Exception as e:
            print(f"[lora] דילוג על {os.path.basename(fp)}: {str(e)[:120]}")


def generate_image(engine_id, prompt, negative="", seed=0, width=1024, height=1536,
                   steps=32, cfg=6.0, lora_dir=None, lora_scale=0.8):
    """רינדור תמונה מקומי. מחזיר PIL.Image ופרטי ריצה.
    שים לב: פורמט רחב (1536x1024) לחדות פנים — לקח כיול 14/10."""
    import torch
    pipe = get_pipe(engine_id)
    key = f"{engine_id}|{lora_dir}|{lora_scale}"
    if lora_dir and _PIPE.get("_lora_key") != key:
        for e in list(_PIPE):
            if e != engine_id:
                _PIPE.pop(e, None)
        pipe.unload_lora_weights() if hasattr(pipe, "unload_lora_weights") else None
        apply_loras(pipe, lora_dir, lora_scale)
        _PIPE["_lora_key"] = key
    dev, _ = detect_device()
    g = torch.Generator(dev if dev != "cpu" else "cpu").manual_seed(int(seed) or 0)
    out = pipe(prompt=prompt, negative_prompt=negative or None, width=width, height=height,
               num_inference_steps=steps, guidance_scale=cfg, generator=g)
    return out.images[0]


def img2img(engine_id, init_image, prompt, negative="", strength=0.75, seed=0,
            steps=32, cfg=6.0):
    """img2img — הדרך המוכחת לתנוחות גב (לקח 14/10: מטקסט בלבד 6/6 זרעים יצאו חזית;
    רפרנס גב מאושר נועל את הפוזה). init_image: PIL.Image או נתיב."""
    import torch
    from PIL import Image
    from diffusers import StableDiffusionXLImg2ImgPipeline
    if isinstance(init_image, str):
        init_image = Image.open(init_image).convert("RGB")
    with _LOCK:
        if "_i2i" not in _PIPE:
            base = get_pipe(engine_id)
            i2i = StableDiffusionXLImg2ImgPipeline(**base.components)
            _PIPE["_i2i"] = i2i
        i2i = _PIPE["_i2i"]
    dev, _ = detect_device()
    g = torch.Generator(dev if dev != "cpu" else "cpu").manual_seed(int(seed) or 0)
    out = i2i(prompt=prompt, negative_prompt=negative or None, image=init_image,
              strength=strength, num_inference_steps=steps, guidance_scale=cfg, generator=g)
    return out.images[0]


def status():
    """סטטוס התקנה ל-UI."""
    dev, dtype = detect_device()
    return {
        "device": dev, "dtype": str(dtype),
        "engines": {k: {"desc": v["desc"], "min_vram_gb": v["min_vram_gb"],
                        "downloaded": _model_cached(v["repo"])} for k, v in IMAGE_ENGINES.items()},
    }


def _model_cached(repo):
    """בדיקה גסה אם המודל כבר במטמון HF המקומי."""
    try:
        from huggingface_hub import scan_cache_file  # noqa
    except Exception:
        pass
    home = os.path.join(os.path.expanduser("~"), ".cache", "huggingface", "hub")
    slug = "models--" + repo.replace("/", "--")
    return os.path.isdir(os.path.join(home, slug))
