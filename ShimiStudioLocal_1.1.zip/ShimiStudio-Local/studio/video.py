# -*- coding: utf-8 -*-
"""ShimiStudio Local — וידאו מקומי (ללא ענן).
מנועים: LTX-Video (I2V, 8GB) ו-Wan 2.1 T2V-1.3B (12GB+).
לקח NaN מ-11/10 מיושם בשניהם: קידוד הטקסט (T5/UMT5) נטען ב-fp32 תמיד."""

VIDEO_ENGINES = {
    "ltx_video": {
        "desc": "LTX-Video — מתמונה לוידאו 5 שניות, מהיר, 8GB VRAM",
        "min_vram_gb": 8, "kind": "i2v",
    },
    "wan21_t2v13b": {
        "desc": "Wan 2.1 T2V 1.3B — מטקסט, איכות גבוהה, 12GB VRAM",
        "min_vram_gb": 12, "kind": "t2v",
    },
}

_LTX = None


def _device():
    import torch
    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def generate_video_ltx_i2v(image_path, prompt, out_path, num_frames=96,
                           width=768, height=512, seed=0):
    """מנפיש תמונה לוידאו (5 שניות @ 24fps לפי 96 פריימים)."""
    import torch
    from diffusers import LTXImageToVideoPipeline
    global _LTX
    dev = _device()
    if _LTX is None:
        _LTX = LTXImageToVideoPipeline.from_pretrained(
            "Lightricks/LTX-Video",
            torch_dtype=torch.bfloat16 if dev != "cpu" else torch.float32)
        if dev == "cuda":
            _LTX.enable_model_cpu_offload()
    negative = "worst quality, inconsistent motion, blurry, jittery, distorted"
    g = torch.Generator(dev if dev != "mps" else "cpu").manual_seed(int(seed) or 0)
    out = _LTX(image=image_path, prompt=prompt, negative_prompt=negative,
               width=width, height=height, num_frames=num_frames,
               guidance_scale=3.0, num_inference_steps=30, generator=g)
    frames = out.frames[0]
    from diffusers.utils import export_to_video
    export_to_video(frames, out_path, fps=24)
    return out_path


def generate_video_wan_t2v(prompt, out_path, frames=81, seed=0):
    """Wan 2.1 T2V 1.3B מטקסט. UMT5 ב-fp32 (לקח NaN), השאר fp16."""
    import torch
    from diffusers import WanPipeline, AutoencoderKLWan
    from transformers import UMT5EncoderModel, T5TokenizerFast
    repo = "Wan-AI/Wan2.1-T2V-1.3B-Diffusers"
    tok = T5TokenizerFast.from_pretrained(repo, subfolder="tokenizer")
    enc = UMT5EncoderModel.from_pretrained(repo, subfolder="text_encoder",
                                           torch_dtype=torch.float32)  # fp32 — מנע NaN מוכח
    vae = AutoencoderKLWan.from_pretrained(repo, subfolder="vae", torch_dtype=torch.float32)
    dev = _device()
    dtype = torch.float16 if dev == "cuda" else torch.float32
    pipe = WanPipeline.from_pretrained(repo, text_encoder=enc, tokenizer=tok, vae=vae,
                                       torch_dtype=dtype)
    if dev == "cuda":
        pipe.enable_model_cpu_offload()
    g = torch.Generator(dev if dev != "mps" else "cpu").manual_seed(int(seed) or 0)
    out = pipe(prompt=prompt, negative_prompt="low quality, blurry", height=480, width=832,
               num_frames=frames, guidance_scale=5.0, generator=g)
    from diffusers.utils import export_to_video
    export_to_video(out.frames[0], out_path, fps=16)
    return out_path


def status():
    return {k: {"desc": v["desc"], "min_vram_gb": v["min_vram_gb"], "kind": v["kind"]}
            for k, v in VIDEO_ENGINES.items()}
