# -*- coding: utf-8 -*-
"""ShimiStudio Local — שערי איכות אוטומטיים (הסטנדרט שהוכח בריצת הארבע-על-ארבע 14/10):
זיהוי פנים YuNet + יחס עור YCrCb + גודל קובץ. הבונה אינו המבקר — השער רק מסנן, האישור הסופי של סאן."""

import os
import numpy as np
import cv2

_HERE = os.path.dirname(os.path.abspath(__file__))

# רף הכרעה (הוכרז מראש, לא מותאם אחרי ריצה):
#   פוזת גב: 0 פנים מזוהות | פוזה חזית/צד: >=1 פנים
#   יחס עור > 0.5 (עירום/ביגוד טסט) | קובץ > 300KB (לא יציאה דחוסה גסה)
SKIN_THRESHOLD = 0.5
MIN_BYTES = 300_000
FACE_CONF = 0.6


class GateResult(dict):
    pass


def _detector(w, h):
    return cv2.FaceDetectorYN.create(os.path.join(_HERE, "yunet.onnx"), "", (320, 320), FACE_CONF)


def analyze(image_path, expect="any"):
    """expect: 'back' (0 פנים) | 'front' (>=1) | 'any' (ללא דרישת פנים). מחזיר דוח שער."""
    img = cv2.imread(image_path)
    if img is None:
        return GateResult(ok=False, error="קובץ תמונה לא נקרא", path=image_path)
    h, w = img.shape[:2]
    det = _detector(w, h)
    det.setInputSize((w, h))
    n, res = det.detect(img)
    faces = 0 if res is None else int(res.shape[0])
    ycc = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
    skin = float(((ycc[..., 1] > 133) & (ycc[..., 1] < 173) &
                  (ycc[..., 2] > 77) & (ycc[..., 2] < 127)).mean())
    size = os.path.getsize(image_path)
    if expect == "back":
        face_ok = (faces == 0)
    elif expect == "front":
        face_ok = (faces >= 1)
    else:
        face_ok = True
    ok = face_ok and skin > SKIN_THRESHOLD and size > MIN_BYTES
    return GateResult(ok=ok, faces=faces, skin=round(skin, 3), bytes=size,
                      w=w, h=h, expect=expect,
                      face_ok=face_ok, skin_ok=skin > SKIN_THRESHOLD, size_ok=size > MIN_BYTES)


def contact_sheet(paths, out_path, cols=4, cell=320):
    """מסכת סקירה — כל התוצאות בתמונה אחת."""
    imgs = []
    for p in paths:
        im = cv2.imread(p)
        if im is None:
            continue
        h, w = im.shape[:2]
        s = cell / w
        imgs.append(cv2.resize(im, (cell, int(h * s))))
    if not imgs:
        return None
    rows = (len(imgs) + cols - 1) // cols
    ch = max(im.shape[0] for im in imgs)
    sheet = np.full((rows * ch, cols * cell, 3), 255, np.uint8)
    for i, im in enumerate(imgs):
        r, c = divmod(i, cols)
        sheet[r * ch:r * ch + im.shape[0], c * cell:c * cell + cell] = im
    cv2.imwrite(out_path, sheet)
    return out_path
