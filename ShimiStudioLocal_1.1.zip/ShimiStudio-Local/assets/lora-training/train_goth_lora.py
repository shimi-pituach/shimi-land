# Shimi Studio — LoRA v1: אימון דמות הגותית (SDXL, kohya sd-scripts, T4, בלי פילטרים)
import subprocess, os, urllib.request, time
DS = 'https://base44.app/api/apps/6a901f55a4d9a9b76a095a77/files/mp/public/6a901f55a4d9a9b76a095a77/41ddbe279_goth_dataset.zip'
subprocess.run(['git','clone','-q','--depth','1','https://github.com/kohya-ss/sd-scripts.git'], check=True)
subprocess.run(['pip','install','-q','-r','sd-scripts/requirements.txt'], check=True)
subprocess.run(['pip','install','-q','xformers bitsandbytes'], check=False)
urllib.request.urlretrieve(DS, 'ds.zip')
subprocess.run(['unzip','-q','ds.zip'], check=True)
open('ds_config.toml','w').write('''[general]
shuffle_caption = true
[[datasets]]
resolution = 1024
batch_size = 1
keep_tokens = 1
  [[datasets.subsets]]
  image_dir = "img/1024_goth/images"
  caption_extension = ".txt"
  num_repeats = 1
''')
t0=time.time()
cmd = ['accelerate','launch','--num_cpu_threads_per_process','2','sd-scripts/sdxl_train_network.py',
 '--pretrained_model_name_or_path=stabilityai/stable-diffusion-xl-base-1.0',
 '--pretrained_te_model_name_or_path=laion/CLIP-ViT-bigG-14-laion2B-39B-b160k',
 '--train_data_dir=img','output_name=shimi_goth_v1','max_train_steps=1400',
 '--resolution=1024,1024','learning_rate=1e-4','mixed_precision=fp16',
 '--network_module=networks.lora','network_dim=16','network_alpha=8',
 '--optimizer_type=AdamW8bit','xformers','save_precision=fp16',
 '--network_train_unet_only','gradient_checkpointing','lowram',
 '--bucket_no_upscale','enable_bucket','min_bucket_reso=512','max_bucket_reso=1024',
 '--dataset_config=ds_config.toml','max_data_loader_n_workers=1','save_every_n_epochs=99999']
subprocess.run(cmd, check=True, cwd='.')
print('TRAIN DONE', round(time.time()-t0,1), flush=True)
subprocess.run(['zip','-q','shimi_goth_v1.zip','shimi_goth_v1.safetensors'], check=False)
if not os.path.exists('shimi_goth_v1.zip') and os.path.exists('shimi_goth_v1.safetensors'):
    subprocess.run(['python3','-c',"import shutil; shutil.make_archive('shimi_goth_v1','zip','.','.')"], check=False)
print('LORA READY', flush=True)
