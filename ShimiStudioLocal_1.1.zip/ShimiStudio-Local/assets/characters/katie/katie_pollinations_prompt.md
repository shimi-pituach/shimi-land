# קייטי — פרומפט קנוני ליצירת הדמות (פוליניישנז/טקסט-לתמונה, 13/10)

דמות סינתטית. מקור הזהות: katie_reference_bw_bun.jpg (פנים עדינות, קוקו, גוף דק).
רמת חשיפה לפי הקנון הסינתטי (שלוש תמונות סיגל). אין בגדי טסט של אדם אמיתי.
כל פלט חייב אישור סאן/שימי של סאן (הבונה אינו המבקר).

## פרומפט יצירה (מבוסס הרפרנס, לוק חתום)

```
Young woman in her early twenties, delicate soft facial features, high cheekbones, calm subtle expression, dark brown-black hair tied in a neat low bun with a few loose strands, slim toned figure, graceful long neck, wearing a fitted black sleeveless top, minimalist chic style, black and white fine-art photography, soft studio lighting, shallow depth of field, photorealistic, 85mm lens look, highly detailed skin texture
```

## פרומפט שלילי

```
color image, deformed face, asymmetric eyes, extra fingers, plastic skin, airbrushed, cartoon, anime, blurry, text, watermark, logo, heavy makeup, jewelry, background clutter
```

## פרמטרים מומלצים (אורח/פולי)
model: flux | width: 1024 | height: 1024 | seed: 131013 (נעיל שחוזרות אותן פנים עד אישור) | nologo: true

## וריאנט אימות אנטומי (סינתטי, לפי קנון סיגל)
אותו בלוק דמות, מחליפים את הלבוש:
```
... wearing a sheer delicate floral lace bodysuit, no padding, fine fabric detail, soft lace texture, same black and white fine-art photography, soft studio lighting, photorealistic
```

## חוקים
1. בלוק הדמות לא משתנה בין סצנות; משתנה רק הפעולה/הלבוש.
2. seed נשמר לכל הסדרה של אותה סצנה.
3. שינוי נפח חזה = רק דרך inpaint/Kontext עם רפרנס ג'ין, לא דרך טקסט.

## ביגוד טסט מאושר לדמות סינתטית (סאן, 14/10)
טופלס, חזה טבעי חשוף, חוטיני תחרת פרחים דק שקוף בלבד. גוף מלא מקצה לקצה.
בלוק לפרומפט: topless, bare natural bust, wearing only a thin sheer floral lace thong, full body photograph, head to toe
