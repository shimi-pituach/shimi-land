# קנון מידות דמויות — סגלון חישובי (טיוטה לאישור סאן, 14/10)

עקרון (הצעת סאן 14/10): כל דמות נמדדת במידות גוף מספריות, והפרומפטים חישוביים — עובדות פיזיות ומספרים, פחות תוארים תיאטרליים.
מקור האמת למספרים: סאן (בעל הקנון). הטיוטה שלהלן נגזרה מהרפרנסים המאושרים ומחכה לתיקונו.

## סכמת מידות (ס"מ)
גובה | היקף חזה (נקודה מלאה) | היקף תחת חזה | היקף מותן | היקף ירכיים | גזרה (הפרש חזה-תחת חזה → כוסית)

## סיגל (הגותית)
168 | 101 | 74 | 64 | 104 | כוסית ~G
תוארי גוף מינימליים: חזה טבעי כבד, ישבן עגול בולט.

## קייטי
165 | 94 | 72 | 60 | 92 | כוסית ~DD-E (נפח לפי ג'ין)

## ג'ין
170 | 100 | 76 | 66 | 106 | כוסית ~F-G

## תבנית פרומפט חישובית (דוגמה לסיגל)
```
full body photograph from head to feet, [פוזה/סצנה], 168cm tall pale gothic woman,
measurements: bust 101cm, underbust 74cm, waist 64cm, hips 104cm,
large heavy natural breasts, round prominent buttocks, pale porcelain skin with freckles,
sharp black winged eyeliner, dark plum lipstick, long straight jet-black hair with blunt bangs,
topless, wearing only a thin sheer floral lace thong (minimal rear coverage, thin string sides).
[סגנון: Realistic photography, natural daylight, photorealistic, ultra realistic skin texture]
```

## כללי חישוביות
1. המסגור ראשון ומפורש: "full body photograph from head to feet, entire body visible, feet visible".
2. מידות מספריות לפני תוארים.
3. תוארים מינימליים וטכניים בלבד (large/narrow/wide לפי הפרשי מידות).
4. בלי מטאפורות, בלי "מרשים/מפואר", בלי בלוק שלילי גדול.

## תיקון קנון גוף לפי הוראת סאן (14/10, סבב כיול 2)
* סיגל: חזה ענק טבעי (massive natural bust), גוף שעון חול מלא (narrow waist, wide hips), ישבן ענק עגול. לא רזה, לא אנורקטית. שיער שחור ארוך עם פוני — לא מסתפרת.
* קייטי: מאמנת כושר — גוף מוצק וחטוב, אחוזי שומן נמוכים, חזה זקור (perky), ישבן עגול מוצק (round firm glutes, not flat). הגוף שהוציא המנוע ל"סיגל" בכיול 2 = בעצם הגוף הנכון לקייטי.
* ג'ין: חזה סיליקון (implant look) במידה אחת גדולה ממה שיצא בכיול 2, בטן עגולה (round belly, לא שטוחה) בסגנון סיגל, גוף לא שעון חול.
* קרבת חזה: סיגל וג'ין דומות יותר ביניהן מאשר קייטי לג'ין.
