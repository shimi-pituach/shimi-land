# ג'ין — פרומפט קנוני ליצירת הדמות (פוליניישנז/טקסט-לתמונה, 13/10)

דמות סינתטית. מקור: jean_reference_front.jpg + jean_reference_side.jpg.
ברשת שימי ג'ין משמשת בעיקר כרפרנס צורה ונפח חזה להעברה לקייטי (inpaint), אבל הפרומפט הזה יוצר אותה כדמות עצמאית.
רמת חשיפה לפי הקנון הסינתטי (סיגל).

## פרומפט יצירה (מבוסס הרפרנס, לוק חתום)

```
Young woman in her mid twenties, warm friendly face, soft natural makeup, long wavy auburn-brown hair falling over shoulders, full curvy figure with notably large natural bust, wearing an elegant lace bodysuit, delicate floral lace texture, warm color photography, golden soft lighting, photorealistic, highly detailed skin texture, 85mm lens look
```

## פרומפט שלילי

```
deformed face, asymmetric eyes, extra fingers, plastic skin, airbrushed, cartoon, anime, blurry, text, watermark, logo, heavy jewelry, background clutter, distorted anatomy
```

## פרמטרים מומלצים (אורח/פולי)
model: flux | width: 1024 | height: 1024 | seed: 131013 | nologo: true

## חוקים
1. בלוק הדמות לא משתנה בין סצנות; משתנה רק הפעולה/הלבוש.
2. כשג'ין משמשת כרפרנס נפח לקייטי: לוקחים ממנה רק צורה ונפח חזה, לא פנים, לא שיער, לא גוון עור.
3. כל פלט חייב אישור סאן/שימי של סאן.

## ביגוד טסט מאושר לדמות סינתטית (סאן, 14/10)
טופלס, חזה טבעי חשוף, חוטיני תחרת פרחים דק שקוף בלבד. גוף מלא מקצה לקצה.
בלוק לפרומפט: topless, bare natural bust, wearing only a thin sheer floral lace thong, full body photograph, head to toe
