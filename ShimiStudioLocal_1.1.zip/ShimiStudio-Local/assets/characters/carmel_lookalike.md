# Carmel — דמות מקורית בהשראת סגנון כללי (לא דמות מסחרית)
נוצר 14/10/2026 בהוראת סאן: "דמות שרק נראית כמוהה, לא היא".

## קנון מילולי (לא מעתיק פנים/שם/זהות של אף דמות קיימת)
- אישה בשנות ה-40 המוקדמות שלה, עור חום-נחושת חם
- שיער שחור ארוך ישר, קווצת הדגשה בהירה אחת בקדמת הפנים
- עגילי חישוק זהב, שרשרת זהב עדינה
- גוף שעון חול מלא: חזה טבעי גדול וכבד, מותניים צרים יחסית, ישבן עגול רחב
- מידות מספריות קשיחות: חזה 110, תחת חזה 82, מותניים 78, ישבן 112
- חיוך בוטח, חם

## בגדי טסט (קנון ביגוד טסט לדמות סינתטית, מאושר 14/10)
topless, bare natural bust, wearing only a thin sheer floral lace thong, full body photograph, head to toe

## פרומפט קדמי (front)
topless, bare natural heavy natural bust, wearing only a thin sheer floral lace thong, full body photograph, head to toe, a warm copper-brown skinned woman in her early forties, long straight black hair with one light highlighted streak framing her face, gold hoop earrings, delicate gold chain necklace, full hourglass figure, very large heavy natural breasts, narrow waist, wide round hips, confident warm smile, standing in a clean photography studio, soft even studio lighting, photorealistic, sharp focus on face, 1024x1536

## פרומפט אחורי (back)
topless, bare natural bust, wearing only a thin sheer floral lace thong, full body photograph, head to toe, back view, a warm copper-brown skinned woman in her early forties, long straight black hair falling down her back, full hourglass figure, very large heavy natural bust seen from the side, narrow waist, very wide round bare buttocks, standing in a clean photography studio, soft even studio lighting, photorealistic, 1024x1536

## רף הכרעה
1. ריאליסטי (סגנון צילום, לא אנימציה)
2. טופלס, חזה טבעי חשוף, חוטיני תחרת פרחים דק בלבד, בלי חזיית ספורט/שכבות
3. גוף מלא קצה לקצה
4. מנוע שאינו פולינציונז
