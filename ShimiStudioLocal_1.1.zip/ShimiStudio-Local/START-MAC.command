#!/bin/bash
cd "$(dirname "$0")"
source venv/bin/activate 2>/dev/null || { echo "קודם הרץ install_mac.command"; read -p "Enter לסגירה..."; exit 1; }
python studio/app.py
