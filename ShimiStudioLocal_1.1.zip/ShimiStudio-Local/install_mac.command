#!/bin/bash
# ShimiStudio Local — Mac Installer (Apple Silicon / Intel)
cd "$(dirname "$0")"
echo "===========================================|  ShimiStudio Local — Mac Installer  |"
if ! command -v python3 >/dev/null; then
  echo "[ERROR] Python לא מותקן. התקן Python 3.11+ (brew install python@3.11) והפעל שוב."; read -p "Enter לסגירה..."; exit 1
fi
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip -q
echo "[1/3] מתקין PyTorch (MPS — Apple Silicon)..."
pip install torch -q
echo "[2/3] מתקין ספריות..."
pip install -r requirements.txt -q
echo "[3/3] מוריד מודלים ולורות (RealVisXL ~7GB. אפשר לדלג ולהריץ מאוחר יותר)..."
python download_models.py
echo "הושלם! להפעלה: לחיצה כפולה על START-MAC.command"
read -p "Enter לסגירה..."
