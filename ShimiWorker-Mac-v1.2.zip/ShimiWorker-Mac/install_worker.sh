#!/bin/bash
set -e
echo "=== שימי וורקר — התקנה למאק v1.2 ==="
DEST="$HOME/ShimiWorker"
mkdir -p "$DEST"
cp "$(dirname "$0")/worker.py" "$DEST/"

if ! command -v python3 >/dev/null 2>&1; then
  echo "אין python3 — נפתח חלון התקנת כלי הפיתוח של אפל. אחרי שהיא מסתיימת הרץ שוב."
  xcode-select --install 2>/dev/null || true
  exit 1
fi
# PEP 668: פייתון של Homebrew חוסם pip מערכתי — התקנת משתמש עם דגל המעקף
python3 -m pip install --user --break-system-packages -q requests 2>/dev/null \
  || python3 -m pip install --user -q requests 2>/dev/null \
  || python3 -m pip install -q requests
echo "תלויות הותקנו"

CFG="$DEST/config.json"
if [ -f "$CFG" ]; then
  # config קיים: משלימים שדות חסרים במקום לשמר בעיוורון (הלקח מהווינדוז)
  TOKEN_IN_CFG=$(python3 -c "import json;print(json.load(open('$CFG')).get('token',''))" 2>/dev/null || echo "")
  if [ -z "$TOKEN_IN_CFG" ]; then
    echo "ל-config חסר טוקן — הדבק את הטוקן ששימי פיתוח שלח ולחץ Enter:"
    read -r TOKEN
    python3 - "$TOKEN" << 'EOF'
import json, sys
p = f"{__import__('os').path.expanduser('~')}/ShimiWorker/config.json"
c = json.load(open(p))
c["token"] = sys.argv[1]
json.dump(c, open(p, "w"), ensure_ascii=False, indent=2)
EOF
    echo "טוקן הוזרק ל-config ✓"
  else
    echo "קיים config.json עם טוקן — שומר עליו."
  fi
else
  echo ""
  echo "הדבק את הטוקן ששימי פיתוח שלח בוואטסאפ ולחץ Enter:"
  read -r TOKEN
  SECRET=$(LC_ALL=C tr -dc 'a-z0-9' </dev/urandom | head -c 10)
  cat > "$CFG" <<EOF
{
  "base_url": "https://solas-6a095a77.base44.app",
  "token": "$TOKEN",
  "cmd_secret": "$SECRET",
  "poll_seconds": 10,
  "worker_id": "sun-mac-1",
  "studio_path": "",
  "gallery_local_repo": ""
}
EOF
  echo ""
  echo "=== חובה: שלח לשימי פיתוח בוואטסאפ את שורת החתימה ==="
  echo "WORKER-SECRET-MAC $SECRET"
fi

PLIST="$HOME/Library/LaunchAgents/com.shimi.worker.plist"
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.shimi.worker</string>
  <key>ProgramArguments</key><array>
    <string>$(command -v python3)</string>
    <string>$DEST/worker.py</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>WorkingDirectory</key><string>$DEST</string>
  <key>StandardOutPath</key><string>$DEST/worker_log.txt</string>
  <key>StandardErrorPath</key><string>$DEST/worker_err.txt</string>
</dict></plist>
EOF
launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST"
sleep 2
echo "=== הוורקר עלה ורץ (v1.2, אל-מוות) ==="
echo "יומן מלא: $DEST/worker_log.txt"
