# שימי וורקר למאק v1.1

התקנה (טרמינל):
1. חלץ את הzip ופתח טרמינל בתיקייה (cd אליה).
2. הרץ: bash install_worker.sh
3. הדבק את הטוקן ששימי פיתוח שלח.
4. שלח לשימי פיתוח את השורה WORKER-SECRET-MAC שתופיע בסוף.

פקודות זמינות: status, run, find, readfile, render, gallery_push.
רינדר תמונות דורש התקנת ShimiStudio-Local (studio_path ב-config).
ריצה אוטומטית: LaunchAgent (com.shimi.worker) עם KeepAlive — קם מחדש אחרי קריסה ובכל עליית מחשב.
עצירה: launchctl unload ~/Library/LaunchAgents/com.shimi.worker.plist
