# שימי וורקר — ShimiWorker v1.1 (Windows + macOS) (16/10/2026 — תיקוני בדיקות באגים)
# סוכן מקומי שמאזין לפקודות משימי פיתוח דרך Base44 (ישות IncomingTask) ומחזיר תוצאות.
# מאושר ומותאם אישית עבור סאן. כל פקודה נשמרת ביומן מלא.

import json
import os
import platform
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone

try:
    import requests
except ImportError:
    print("חסר requests — מריץ: pip install requests")
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "requests"])
    import requests

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(HERE, "config.json")
LOG_PATH = os.path.join(HERE, "worker_log.txt")

DEFAULTS = {
    "base_url": "https://solas-6a095a77.base44.app",
    "token": "",
    "poll_seconds": 10,
    "cmd_secret": "",  # v1.1: קידומת חובה לכל פקודה, למשל "shimi7" — פקודה נשלחת כ-shimi7:status
    "worker_id": "sun-windows-1",
    "studio_path": "",  # נתיב ל-ShimiStudio-Local אם מותקן (לפקודת render)
    "github_push_url": "",  # אופציונלי: remote עם טוקן לדחיפת גלריה
    "gallery_local_repo": "",  # נתיב למאגר shimi-land מקומי (clone)
}


def load_config():
    cfg = dict(DEFAULTS)
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg.update(json.load(f))
    if not cfg.get("token"):
        print("אין טוקן ב-config.json — הרץ קודם install_worker.ps1 או מלא ידנית.")
        sys.exit(1)
    return cfg


def log(msg):
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line)
    try:
        if os.path.exists(LOG_PATH) and os.path.getsize(LOG_PATH) > 5_000_000:
            with open(LOG_PATH, encoding="utf-8") as f:
                tail = f.read()[-200_000:]
            with open(LOG_PATH, "w", encoding="utf-8") as f:
                f.write("[יומן חותך — נשמרו 200KB אחרונים]\n" + tail)
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def api(cfg, method, path, payload=None, params=None, timeout=30):
    url = cfg["base_url"].rstrip("/") + path
    headers = {
        "Authorization": "Bearer " + cfg["token"],
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (ShimiWorker/1.0)",
    }
    r = requests.request(method, url, headers=headers, json=payload,
                         params=params, timeout=timeout)
    r.raise_for_status()
    return r.json() if r.content else {}


def fetch_tasks(cfg):
    d = api(cfg, "GET", "/api/entities/IncomingTask",
            params={"source": "windows-worker", "status": "pending", "limit": "5"})
    return d if isinstance(d, list) else []


def update_task(cfg, task_id, data):
    return api(cfg, "PUT", f"/api/entities/IncomingTask/{task_id}", payload=data)


def cmd_status(cfg, args):
    info = {
        "worker_id": cfg.get("worker_id"),
        "hostname": platform.node(),
        "os": platform.platform(),
        "python": sys.version.split()[0],
        "time": datetime.now().isoformat(timespec="seconds"),
    }
    if platform.system() == "Darwin":
        try:
            chip = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"],
                                  capture_output=True, text=True, timeout=10).stdout.strip()
            try:
                m1 = subprocess.run(["system_profiler", "SPDisplaysDataType"],
                                     capture_output=True, text=True, timeout=15).stdout
                import re as _re
                m = _re.search(r"Chipset Model:\s*(.+)", m1)
                chip = (m.group(1).strip() + " | " + chip) if m else chip
                m2 = _re.search(r"VRAM[^:]*:\s*(.+)", m1)
                if m2: chip += " | " + m2.group(1).strip()
            except Exception:
                pass
            info["gpu"] = chip
        except Exception:
            info["gpu"] = "Apple Silicon — לא זוהה במפורט"
    else:
        try:
            gpu = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version",
                                  "--format=csv,noheader"], capture_output=True, text=True, timeout=20)
            info["gpu"] = gpu.stdout.strip()
        except Exception:
            info["gpu"] = "לא זוהה כרטיס NVIDIA / nvidia-smi לא זמין"
    import shutil
    du = shutil.disk_usage(os.path.abspath(os.sep))
    info["disk_free_gb"] = round(du.free / 1e9, 1)
    return json.dumps(info, ensure_ascii=False)


def cmd_run(cfg, args):
    timeout = 600
    if args and args[0].startswith("timeout="):
        timeout = int(args[0].split("=", 1)[1])
        args = args[1:]
    command = " ".join(args)
    if not command:
        return "ERROR: חסרה פקודה. שימוש: run timeout=120 dir"
    log(f"RUN: {command} (timeout={timeout}s)")
    try:
        p = subprocess.run(command, shell=True, capture_output=True,
                           text=True, timeout=timeout, encoding="utf-8", errors="replace")
        out = (p.stdout or "")[-6000:]
        err = (p.stderr or "")[-2000:]
        return f"exit={p.returncode}\nSTDOUT:\n{out}\nSTDERR:\n{err}"
    except subprocess.TimeoutExpired:
        return f"ERROR: פסק זמן {timeout}s"
    except Exception as e:
        return "ERROR: " + str(e)[:500]


def cmd_find(cfg, args):
    import glob as g
    pattern = args[0] if args else "*"
    root = args[1] if len(args) > 1 else os.path.expanduser("~")
    matches = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames
                       if not d.startswith("$")
                       and "AppData" not in os.path.join(dirpath, d)
                       and "node_modules" not in d][:400]
        for fn in filenames:
            if g.fnmatch.fnmatch(fn.lower(), pattern.lower()):
                matches.append(os.path.join(dirpath, fn))
                if len(matches) >= 200:
                    return "\n".join(matches) + "\n... (נחתך ב-200)"
    return "\n".join(matches) if matches else "לא נמצאו קבצים"


def cmd_readfile(cfg, args):
    if not args:
        return "ERROR: שימוש: readfile <נתיב> [שורות]"
    path = args[0]
    tail = int(args[1]) if len(args) > 1 else 400
    try:
        with open(path, "rb") as f:
            data = f.read(2_000_000)
        text = data.decode("utf-8", errors="replace")
        lines = text.splitlines()
        return "\n".join(lines[-tail:]) if len(lines) > tail else text
    except Exception as e:
        return "ERROR: " + str(e)[:300]


def cmd_render(cfg, args):
    studio = cfg.get("studio_path")
    if not studio or not os.path.isdir(studio):
        return "ERROR: studio_path לא מוגדר ב-config.json (נתיב ל-ShimiStudio-Local). מילאי אותו אחרי התקנת הסטודיו."
    # args: JSON עם prompt/negative/seed/width/height/engine/character
    try:
        spec = json.loads(" ".join(args)) if args else {}
    except Exception:
        return "ERROR: args חייבים להיות JSON תקין"
    out_dir = os.path.join(HERE, "renders")
    os.makedirs(out_dir, exist_ok=True)
    script = os.path.join(studio, "studio", "render_one.py")
    if not os.path.exists(script):
        return "ERROR: חסר studio/render_one.py בסטודיו (עדכן לגרסה עם render_one)."
    spec["out_dir"] = out_dir
    p = subprocess.run([sys.executable, script], input=json.dumps(spec),
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=1800, cwd=studio)
    return (p.stdout or "")[-4000:] + (("\nERR:" + (p.stderr or "")[-1500:]) if p.returncode else "")


def cmd_gallery_push(cfg, args):
    repo = cfg.get("gallery_local_repo")
    if not repo or not os.path.isdir(repo):
        return "ERROR: gallery_local_repo לא מוגדר. הרץ קודם: run git clone <url> <repo>"
    steps = [
        ["git", "-C", repo, "add", "-A"],
        ["git", "-C", repo, "commit", "-m", f"worker render {datetime.now().strftime('%H:%M')}"],
        ["git", "-C", repo, "push"],
    ]
    outs = []
    for s in steps:
        p = subprocess.run(s, capture_output=True, text=True, timeout=120, encoding="utf-8", errors="replace")
        outs.append((p.stdout or p.stderr or "").strip()[-200:])
    return "\n".join(outs)


HANDLERS = {
    "status": cmd_status,
    "run": cmd_run,
    "find": cmd_find,
    "readfile": cmd_readfile,
    "render": cmd_render,
    "gallery_push": cmd_gallery_push,
}


def execute(cfg, task):
    instruction = (task.get("instruction") or "").strip()
    secret = str(cfg.get("cmd_secret") or "")
    if secret:
        if not instruction.startswith(secret + ":"):
            return "denied", "נדחה: הפקודה לא חתומה בסוד המשותף. לא בוצע כלום."
        instruction = instruction[len(secret) + 1:].strip()
    parts = instruction.split()
    verb = parts[0].lower() if parts else "status"
    args = parts[1:] if verb in HANDLERS else parts
    handler = HANDLERS.get(verb, cmd_run)
    if verb in HANDLERS:
        result = handler(cfg, args)
    else:
        result = cmd_run(cfg, parts)
    return verb, result

def main():
    cfg = load_config()
    log(f"שימי וורקר עלה. worker_id={cfg['worker_id']} — מאזין לתור (source=windows-worker)")
    last_heartbeat = 0
    fails = 0
    while True:
        try:
            fails = 0
            tasks = fetch_tasks(cfg)
            for t in tasks:
                tid = t.get("id")
                log(f"פקודה התקבלה [{tid}]: {(t.get('instruction') or '')[:120]}")
                update_task(cfg, tid, {"status": "in_progress"})
                try:
                    verb, result = execute(cfg, t)
                except Exception:
                    result = "ERROR: " + traceback.format_exc()[-2000:]
                    verb = "error"
                update_task(cfg, tid, {
                    "status": "done",
                    "processed": True,
                    "processed_at": datetime.now(timezone.utc).isoformat(),
                    "task_code": verb if verb in HANDLERS else (t.get("task_code") or verb),
                    "title": ((t.get("title") or "פקודה") + " | בוצע " + datetime.now().strftime("%H:%M")),
                    "instruction": (t.get("instruction") or "") + "\n─── RESULT ───\n" + result[:7000],
                })
                log(f"פקודה [{tid}] הושלמה ({verb}). תוצאה: {len(result)} תווים")
        except Exception as e:
            fails += 1
            wait = 15 * min(fails, 20)
            log(f"שגיאת לולאה (כישלון רצוף {fails}, המתנה {wait}s): " + str(e)[:300])
            if fails >= 10:
                log("10 כישלונות רצופים — כנראה טוקן/חיבור. הוורקר ממשיך לנסות בהפסקות.")
            time.sleep(wait)
        # heartbeat: דופק כל 5 דקות ברשומת סטטוס
        now = time.time()
        if now - last_heartbeat > 300:
            last_heartbeat = now
            try:
                hb_key = f"worker_heartbeat_{cfg['worker_id']}"
                hb_val = datetime.now(timezone.utc).isoformat()
                try:
                    recs = api(cfg, "GET", "/api/entities/SystemSettings",
                               params={"key": hb_key, "limit": "1"})
                    if isinstance(recs, list) and recs:
                        api(cfg, "PUT", f"/api/entities/SystemSettings/{recs[0]['id']}",
                            payload={"value": hb_val})
                    else:
                        api(cfg, "POST", "/api/entities/SystemSettings", payload={
                            "key": hb_key, "value": hb_val,
                            "description": "דופק שימי וורקר על מחשב סאן",
                        })
                except Exception:
                    pass
            except Exception:
                pass
        time.sleep(cfg.get("poll_seconds", 10))


if __name__ == "__main__":
    main()
