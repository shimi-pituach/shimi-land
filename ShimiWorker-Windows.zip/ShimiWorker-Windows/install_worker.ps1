# שימי וורקר — התקנה ל-Windows v1.0
# מריץ: PowerShell כמנהל (קליק ימני → Run as Administrator)

$ErrorActionPreference = "Stop"
$Dest = "C:\ShimiWorker"

Write-Host "=== שימי וורקר — התקנה ===" -ForegroundColor Cyan

# 1. בדיקת Python
$py = Get-Command python -ErrorAction SilentlyContinue
if (-not $py) {
    Write-Host "Python לא מותקן — מתקין דרך winget..." -ForegroundColor Yellow
    winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    # רענון PATH בסשן הנוכחי
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    $py = Get-Command python -ErrorAction SilentlyContinue
    if (-not $py) { Write-Host "התקנת Python נכשלה — התקן ידנית מ-python.org והרץ שוב." -ForegroundColor Red; exit 1 }
}
Write-Host "Python: $($py.Source)" -ForegroundColor Green

# 2. העתקת הקבצים
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item "$PSScriptRoot\worker.py" $Dest -Force
Write-Host "קבצים הועתקו ל-$Dest" -ForegroundColor Green

# 3. תלויות
python -m pip install -q --upgrade requests
Write-Host "תלויות הותקנו" -ForegroundColor Green

# 4. טוקן (מקבלים משימי פיתוח בוואטסאפ)
$existingCfg = Test-Path "$Dest\config.json"
if ($existingCfg) {
    Write-Host "קיים config.json — שומר עליו." -ForegroundColor Yellow
} else {
    Write-Host ""
    $token = Read-Host "הדבק כאן את הטוקן ששימי פיתוח שלח בוואטסאפ ולחץ Enter"
    $cfg = @{
        base_url = "https://solas-6a095a77.base44.app"
        token = $token
        poll_seconds = 10
        worker_id = "sun-windows-1"
        studio_path = ""
        gallery_local_repo = ""
    }
    $cfg | ConvertTo-Json | Out-File "$Dest\config.json" -Encoding utf8
    Write-Host "config.json נוצר" -ForegroundColor Green
}

# 5. קיצור דרך בתיקיית ההפעלה (מריץ ברקע בכל עליית מחשב)
$vbs = "$Dest\start_worker.vbs"
@"
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "$Dest"
WshShell.Run """" & "python" & """" & " " & """" & "$Dest\worker.py" & """", 0, False
"@ | Out-File $vbs -Encoding ascii

$startup = [Environment]::GetFolderPath("Startup")
Copy-Item $vbs "$startup\ShimiWorker.vbs" -Force
Write-Host "נרשף להפעלה אוטומטית בעת עליית המחשב" -ForegroundColor Green

# 6. פתיחה חד-פעמית עכשיו
Start-Process wscript.exe -ArgumentList "`"$vbs`""
Write-Host ""
Write-Host "=== הוורקר עלה ורץ! ===" -ForegroundColor Cyan
Write-Host "שימי פיתוח ידבר אליו דרך תור הפקודות. יומן מלא: $Dest\worker_log.txt"
Write-Host "לבדיקה: שלח לשימי פיתוח 'שלח status לוורקר' והוא יחזיר את פרטי המחשב."
